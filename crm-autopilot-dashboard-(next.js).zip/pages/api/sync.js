
import { google } from 'googleapis'
import OpenAI from 'openai'
import { GoogleGenAI } from "@google/genai"; // Updated import
import axios from 'axios'
import fs from 'fs'
import path from 'path'

const GEMINI_MODEL_NAME_BACKEND = 'gemini-2.5-flash-preview-04-17';

// Initialize Google Sheets, Calendar, and Gmail APIs
const getGoogleAuth = () => {
  let privateKey = process.env.GOOGLE_PRIVATE_KEY
  if (privateKey) {
    // Robust private key formatting for environment variables
    privateKey = privateKey.replace(/\\n/g, '\n')
    if (!privateKey.includes('\n') && privateKey.includes('-----BEGIN PRIVATE KEY-----') && privateKey.includes('-----END PRIVATE KEY-----')) {
      privateKey = privateKey.replace(/-----BEGIN PRIVATE KEY-----/, '-----BEGIN PRIVATE KEY-----\n')
      privateKey = privateKey.replace(/-----END PRIVATE KEY-----/, '\n-----END PRIVATE KEY-----')
      privateKey = privateKey.replace(/(.{64})(?!$)/g, '$1\n') // Add newline every 64 chars, but not at the very end
    }
  }
  
  return new google.auth.JWT(
    process.env.GOOGLE_SERVICE_EMAIL,
    null,
    privateKey,
    [
      'https://www.googleapis.com/auth/spreadsheets',
      'https://www.googleapis.com/auth/calendar.readonly',
      'https://www.googleapis.com/auth/gmail.readonly'
    ]
  )
}

const getGmailOAuthClient = () => {
  const TOKEN_PATH = path.join(process.cwd(), 'gmail-tokens.json') // For NextAuth.js or similar persistent OAuth
  try {
    if (fs.existsSync(TOKEN_PATH)) {
      const tokenData = fs.readFileSync(TOKEN_PATH, 'utf8')
      const tokens = JSON.parse(tokenData)
      const oauth2Client = new google.auth.OAuth2(
        process.env.GOOGLE_CLIENT_ID,
        process.env.GOOGLE_CLIENT_SECRET,
        `${process.env.NEXTAUTH_URL || 'http://localhost:3000'}/api/auth/gmail/callback` // Ensure this callback is handled
      )
      oauth2Client.setCredentials(tokens)
      logMessage('Using OAuth Gmail authentication via stored tokens.')
      return oauth2Client
    }
    logMessage('OAuth token file (gmail-tokens.json) not found.')
    return null
  } catch (error) {
    logMessage(`Error reading OAuth tokens: ${error.message}. Falling back for Gmail.`)
    return null
  }
}

const getAIClient = () => {
  if (process.env.OPENAI_API_KEY) {
    logMessage('Using OpenAI API client.');
    return new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  } else if (process.env.GEMINI_API_KEY) {
    logMessage('Using Gemini API client.');
    return new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY }); // Updated initialization
  }
  throw new Error('No AI API key configured (OPENAI_API_KEY or GEMINI_API_KEY).')
}

const logMessage = (message) => {
  console.log(`[SYNC] ${new Date().toISOString()}: ${message}`)
}

const shouldSkipEmail = (email) => {
  if (!email) return true
  const emailLower = email.toLowerCase()
  if (emailLower.includes('@viehq.com') || emailLower === 'fred@fireflies.ai' || emailLower === process.env.GOOGLE_SERVICE_EMAIL?.toLowerCase()) {
    // logMessage(`Skipping designated email: ${email}`) // Can be too verbose
    return true
  }
  const skipDomains = ['@noreply.', '@notifications.', '@calendly.com', '@zoom.us', '@teams.microsoft.com', '@meet.google.com', '@fireflies.ai'] // Added @fireflies.ai generally, fred@ is an exception for fetching.
  if (skipDomains.some(domain => emailLower.includes(domain) && emailLower !== 'fred@fireflies.ai')) {
    // logMessage(`Skipping system email: ${email}`) // Can be too verbose
    return true
  }
  return false
}

function getNameFromEmail(email) {
  if (!email || !email.includes('@')) return 'Unknown Name'
  const localPart = email.split('@')[0]
  return localPart.replace(/[._-]/g, ' ').split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')
}

async function analyzeWithAI(notesContent, contactName, sourceType) {
  if (!notesContent || notesContent.trim().length < 20) {
    logMessage(`Skipping AI for ${contactName} (source: ${sourceType}): insufficient content.`)
    return { status: 'Manual Review Needed', nextStep: 'Insufficient content for AI', notes: `No meaningful content from ${sourceType}.` }
  }
  const aiClient = getAIClient()
  const contactNameToUse = contactName || getNameFromEmail(contactName) // Ensure contactName is sensible

  let prompt = sourceType === 'Fireflies API' || sourceType === 'Fireflies Email' ?
`Analyze this Fireflies meeting content for CRM. Contact: ${contactNameToUse}.
Extract:
1. Investment interest/sentiment (e.g., 'High Interest', 'Passed', 'Follow-up needed').
2. Specific next actions or commitments for us or the contact.
3. Key concerns, requirements, or objections raised.
4. Decision timelines or funding amounts mentioned.
5. Other critical CRM notes (e.g., important facts, connections).
Output strictly as a JSON object with keys: "status", "nextStep", "notes" (combine 3,4,5 into notes, max 300 chars).
Content (max 7000 chars):
---
${notesContent.substring(0, 7000)}
---` :
`Summarize this meeting content for a CRM. Contact: ${contactNameToUse}.
Extract:
1. Investment status or overall sentiment (e.g., 'Interested', 'Passed', 'Information gathering').
2. The single most important next step for us or the contact.
3. A brief summary of key discussion points (max 300 chars for notes).
Output strictly as a JSON object with keys: "status", "nextStep", "notes".
Content (max 7000 chars):
---
${notesContent.substring(0, 7000)}
---`
  logMessage(`AI Prompt for ${contactNameToUse} (source: ${sourceType}): ${prompt.substring(0,200)}...`)
  
  try {
    let analysisResultText;
    if (process.env.OPENAI_API_KEY) {
      const completion = await aiClient.chat.completions.create({ model: 'gpt-4-turbo-preview', messages: [{role:'user',content:prompt}], response_format: {type:"json_object"}, temperature:0.3 });
      analysisResultText = completion.choices[0]?.message?.content;
    } else if (process.env.GEMINI_API_KEY) {
      const response = await aiClient.models.generateContent({ // Updated Gemini call
        model: GEMINI_MODEL_NAME_BACKEND,
        contents: prompt,
        config: {
          responseMimeType: "application/json",
          temperature: 0.3 
        }
      });
      analysisResultText = response.text; // Updated text extraction
    } else {
      throw new Error('No AI client configured properly.');
    }

    logMessage(`Raw AI Response for ${contactNameToUse} (${sourceType}): ${analysisResultText || 'empty'}`);
    if (!analysisResultText) throw new Error('AI response was empty.');

    let parsedAnalysis;
    try {
      let jsonStr = analysisResultText.trim();
      const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s; // Matches ```json ... ``` or ``` ... ```
      const match = jsonStr.match(fenceRegex);
      if (match && match[2]) {
        jsonStr = match[2].trim(); // Trim the extracted content itself
      }
      parsedAnalysis = JSON.parse(jsonStr);
    } catch (e) {
      logMessage(`Failed AI JSON parse for ${contactNameToUse}: ${e.message}. Raw response: ${analysisResultText}`);
      // Fallback: try to extract JSON object using a more general regex if parsing failed
      const looseJsonMatch = analysisResultText.match(/{\s*["']status["']\s*:\s*.*?\s*}/s);
      if (looseJsonMatch && looseJsonMatch[0]) {
        try {
          parsedAnalysis = JSON.parse(looseJsonMatch[0]);
          logMessage(`Successfully parsed with loose JSON match for ${contactNameToUse}.`);
        } catch (e2) {
          logMessage(`Loose JSON match parsing also failed for ${contactNameToUse}: ${e2.message}`);
          throw new Error('AI response not valid JSON despite recovery attempts.');
        }
      } else {
        throw new Error('AI response not valid JSON and no fallback match found.');
      }
    }
    return { status:parsedAnalysis.status||'Manual Review', nextStep:parsedAnalysis.nextStep||'Review AI Output', notes:parsedAnalysis.notes||'AI notes missing or parse error.'};
  } catch (e) { 
    logMessage(`AI analysis failed for ${contactNameToUse} (source: ${sourceType}): ${e.message}`);
    return { status:'Manual Review Required', nextStep:'Review AI Failure', notes:`AI processing failed: ${e.message.substring(0,200)}`};
  }
}

async function recordSyncTimestamp(auth) {
  const sheets = google.sheets({ version: 'v4', auth }); const timestamp = new Date().toISOString();
  try { 
    await sheets.spreadsheets.values.update({ 
      spreadsheetId:process.env.GOOGLE_SHEET_ID, 
      range:'Contacts!H1', // Assuming H1 is dedicated for "Last Sync Timestamp"
      valueInputOption:'USER_ENTERED', 
      resource:{values:[["Last Sync: " + timestamp]]}
    }); 
    logMessage(`Recorded sync timestamp: ${timestamp}`);
  } catch (e) { 
    logMessage(`Error recording sync timestamp: ${e.message}`);
  }
}

export default async function handler(req, res) {
  const cronSecret = req.headers['x-cron-secret'] || req.body?.cronSecret; // Support body for testing
  if (!cronSecret || cronSecret !== process.env.CRON_SECRET) { 
    logMessage('Unauthorized: Invalid CRON_SECRET.');
    return res.status(401).json({ error: 'Unauthorized' });
  }
  if (req.method !== 'POST') {
    logMessage(`Method not allowed: ${req.method}`);
    return res.status(405).json({ error: 'Method not allowed' });
  }

  logMessage('CRON job authorized. Starting sync process...');
  try {
    if (!process.env.GOOGLE_SHEET_ID) throw new Error("GOOGLE_SHEET_ID not configured.");

    const auth = getGoogleAuth(); 
    await auth.authorize(); // Ensure service account is authorized
    logMessage('Google service account auth successful.');

    const calendarEvents = await getCalendarEvents(auth); 
    logMessage(`Found ${calendarEvents.length} potentially relevant calendar events.`);
    
    const existingContacts = await getSheetContacts(auth); 
    logMessage(`Found ${existingContacts.length} existing contacts from Google Sheet.`);
    
    const processedContacts = new Map(); // Using email as key to manage updates

    for (const event of calendarEvents) {
      try {
        logMessage(`Processing event: "${event.summary || 'No Summary'}" on ${event.start?.dateTime || event.start?.date}`);
        const attendeeEmails = event.attendees?.map(a => a.email).filter(Boolean) || [];
        
        for (const email of attendeeEmails) {
          if (shouldSkipEmail(email)) continue;

          let contact = processedContacts.get(email) || existingContacts.find(c => c.email === email);
          
          if (!contact) {
            contact = { 
              name: getNameFromEmail(email), 
              email, 
              status: 'New Contact from Calendar', 
              nextStep: 'Initial follow-up based on meeting', 
              notes: `Met on: ${new Date(event.start?.dateTime || event.start?.date).toLocaleDateString()}. Event: ${event.summary || 'N/A'}`, 
              lastMeeting: event.start?.dateTime || event.start?.date, 
              createdAt: new Date().toISOString()
            };
            logMessage(`New contact identified from event: ${email}`);
          } else {
             logMessage(`Processing existing contact: ${email}`);
          }

          // Attempt to get meeting notes if not recently processed or notes are generic
          let meetingNotes = null;
          // Add logic here if you want to avoid re-fetching notes too often for same contact/event
          try {
             meetingNotes = await getMeetingNotes(email, event.start?.dateTime, event.summary, auth);
             if (meetingNotes) {
                logMessage(`Found notes for ${email} from ${meetingNotes.source} for event: "${event.summary || 'N/A'}"`);
                const analysis = await analyzeWithAI(meetingNotes.content, contact.name || email, meetingNotes.source);
                contact.status = analysis.status || contact.status;
                contact.nextStep = analysis.nextStep || contact.nextStep;
                // Append notes if new, or overwrite if AI is considered authoritative
                contact.notes = analysis.notes ? `${meetingNotes.source} Summary: ${analysis.notes}` : (contact.notes || `Meeting on ${new Date(event.start?.dateTime || event.start?.date).toLocaleDateString()}`);
                logMessage(`AI analysis for ${email}: Status: ${analysis.status}, Next Step: ${analysis.nextStep}`);
             } else {
                logMessage(`No specific meeting notes found for ${email} for event "${event.summary || 'N/A'}" beyond calendar details.`);
             }
          } catch (e) {
            logMessage(`Error fetching/analyzing notes for ${email} on event "${event.summary}": ${e.message}`);
          }
          
          // Update last meeting time if this event is newer
          if (new Date(event.start?.dateTime || event.start?.date) > new Date(contact.lastMeeting || 0)) {
            contact.lastMeeting = event.start?.dateTime || event.start?.date;
          }
          processedContacts.set(email, contact);
        }
      } catch (e) { 
        logMessage(`Error processing event "${event.summary || 'Unknown Event'}": ${e.message}`);
      }
    }

    const updatedContacts = Array.from(processedContacts.values());
    if (updatedContacts.length > 0) { 
      await updateSheetContacts(auth, updatedContacts, existingContacts); // Pass existing to merge smartly
      logMessage(`Updated/Wrote ${updatedContacts.length} contacts to Google Sheet.`);
    } else {
      logMessage('No new or updated contacts to write to Google Sheet.');
    }

    await recordSyncTimestamp(auth); 
    logMessage('Sync completed successfully.');
    res.status(200).json({ 
      success: true, 
      message: 'Sync completed successfully.', 
      contactsProcessed: updatedContacts.length, 
      eventsProcessed: calendarEvents.length, 
      timestamp: new Date().toISOString() 
    });

  } catch (e) { 
    logMessage(`CRITICAL SYNC FAILURE: ${e.message}`); 
    console.error('Full Sync Error Details:', e); 
    res.status(500).json({
      error: 'Sync failed',
      message: e.message,
      timestamp: new Date().toISOString()
    });
  }
}

async function getMeetingNotes(email, meetingDate, meetingTitle, auth) {
  // Priority: Fireflies API > Fireflies Email > General Gmail Recap
  try { 
    if (process.env.FIREFLIES_API_KEY) {
      const ffTranscript = await getFirefliesTranscript(email, meetingDate); 
      if (ffTranscript) return { content: ffTranscript, source: 'Fireflies API' };
    }
  } catch(e) {
    logMessage(`Fireflies API failed for ${email}: ${e.message}`);
  }
  
  try { 
    const ffEmailSummary = await getFirefliesEmailSummary(email, meetingDate, meetingTitle, auth); 
    if (ffEmailSummary) return { content: ffEmailSummary, source: 'Fireflies Email' };
  } catch(e) {
    logMessage(`Fireflies email search failed for ${email}: ${e.message}`);
  }
  
  try { 
    const gmailRecap = await getGmailMeetingRecap(email, meetingDate, meetingTitle, auth); 
    if (gmailRecap) return { content: gmailRecap, source: 'Gmail Recap' };
  } catch(e) {
    logMessage(`Gmail recap search failed for ${email}: ${e.message}`);
  }
  
  return null; // No notes found from any source
}

async function getFirefliesEmailSummary(email, meetingDate, meetingTitle, auth) {
  const gmailAuth = getGmailOAuthClient() || auth; // Prefer OAuth if available, else service account
  const gmail = google.gmail({version:'v1', auth: gmailAuth});
  const searchDt = new Date(meetingDate);
  const dayBefore = new Date(searchDt.getTime() - (24 * 60 * 60 * 1000));
  const twoDaysAfter = new Date(searchDt.getTime() + (2 * 24 * 60 * 60 * 1000)); // Widen window slightly

  const searchTerms = [
    `from:fred@fireflies.ai`, // Specific sender
    `after:${Math.floor(dayBefore.getTime()/1000)}`,
    `before:${Math.floor(twoDaysAfter.getTime()/1000)}`,
    `("meeting recap" OR summary OR "meeting overview" OR transcript OR "action items" OR notes)`
  ];
  if (email) searchTerms.push(`to:${email} OR cc:${email} OR bcc:${email} OR "${email}"`); // Make sure email is participant
  if (meetingTitle) {
    const titleWords = meetingTitle.split(' ').filter(w => w.length > 3 && !['meeting','call','sync','intro','and','the','with','for','our'].includes(w.toLowerCase()));
    if (titleWords.length > 0) searchTerms.push(`(${titleWords.join(' OR ')})`);
  }
  
  const query = searchTerms.join(' ');
  try {
    logMessage(`Fireflies email search query: ${query}`);
    const response = await gmail.users.messages.list({ userId: 'me', q: query, maxResults: 3 });
    const messages = response.data.messages || [];
    if (messages.length === 0) { logMessage(`No Fireflies emails found for ${email} matching criteria.`); return null; }

    for (const msg of messages.slice(0, 2)) { // Check top 2 relevant messages
      try {
        const messageData = await gmail.users.messages.get({ userId: 'me', id: msg.id, format: 'full' });
        const subject = messageData.data.payload.headers.find(h => h.name.toLowerCase() === 'subject')?.value || '';
        const fromHeader = messageData.data.payload.headers.find(h => h.name.toLowerCase() === 'from')?.value || '';
        
        if (fromHeader.toLowerCase().includes('fred@fireflies.ai')) {
          const body = extractEmailBody(messageData.data.payload);
          if (body && body.length > 100) { // Basic check for meaningful content
            logMessage(`Found Fireflies email for ${email}: "${subject}"`);
            return `Subject: ${subject}\nFrom: ${fromHeader}\n\n${body}`;
          }
        }
      } catch (e) { logMessage(`Error reading specific Fireflies email content: ${e.message}`); }
    }
    return null;
  } catch (e) {
    logMessage(`Fireflies email search API error: ${e.message}`);
    throw e; // Re-throw to be caught by getMeetingNotes
  }
}

async function getGmailMeetingRecap(email, meetingDate, meetingTitle, auth) {
  const gmailAuth = getGmailOAuthClient() || auth;
  const gmail = google.gmail({version:'v1', auth: gmailAuth});
  const searchDt = new Date(meetingDate);
  const dayBefore = new Date(searchDt.getTime() - (24 * 60 * 60 * 1000));
  const twoDaysAfter = new Date(searchDt.getTime() + (2 * 24 * 60 * 60 * 1000));

  // Looking for emails sent by the contact *to me* or emails *I sent* that are recaps.
  // Assuming 'me' is the service account email or the OAuth'd user.
  const myServiceEmail = process.env.GOOGLE_SERVICE_EMAIL; // Or your primary user email if using OAuth mainly

  const searchTerms = [
    `(from:${email} OR to:${email})`, // Involving the contact
    `(recap OR summary OR notes OR "meeting notes" OR "action items" OR follow-up OR "next steps" OR "key takeaways")`,
    `after:${Math.floor(dayBefore.getTime()/1000)}`,
    `before:${Math.floor(twoDaysAfter.getTime()/1000)}`
  ];
  if (meetingTitle) {
    const titleWords = meetingTitle.split(' ').filter(w => w.length > 3 && !['meeting','call','sync','intro','and','the','with','for','our'].includes(w.toLowerCase()));
    if (titleWords.length > 0) searchTerms.push(`(${titleWords.join(' OR ')})`);
  }
  
  const query = searchTerms.join(' ');
  try {
    logMessage(`Gmail recap search query: ${query}`);
    const response = await gmail.users.messages.list({ userId: 'me', q: query, maxResults: 5 });
    const messages = response.data.messages || [];
    if (messages.length === 0) { logMessage(`No general Gmail recap messages found for ${email} matching criteria.`); return null; }

    for (const msg of messages.slice(0, 3)) { // Check top 3 relevant messages
      try {
        const messageData = await gmail.users.messages.get({ userId: 'me', id: msg.id, format: 'full' });
        const subject = messageData.data.payload.headers.find(h => h.name.toLowerCase() === 'subject')?.value || '';
        const fromHeader = messageData.data.payload.headers.find(h => h.name.toLowerCase() === 'from')?.value || '';
        
        const isRecapKeywords = /recap|summary|notes|follow.?up|action.?items|next.?steps|discussed|meeting.?notes|takeaways/i.test(subject);
        const isFromContact = fromHeader.toLowerCase().includes(email.toLowerCase());
        // Check if it's from the contact, or I sent it and it looks like a recap.
        if (isFromContact || (fromHeader.toLowerCase().includes(myServiceEmail) && isRecapKeywords)) {
          const body = extractEmailBody(messageData.data.payload);
          if (body && body.length > 100) {
            logMessage(`Found Gmail recap involving ${email}: "${subject}" (From: ${fromHeader})`);
            return `Subject: ${subject}\nFrom: ${fromHeader}\n\n${body}`;
          }
        }
      } catch (e) { logMessage(`Error reading specific Gmail recap content: ${e.message}`); }
    }
    return null;
  } catch (e) {
    logMessage(`Gmail recap search API error: ${e.message}`);
    throw e;
  }
}

function extractEmailBody(payload) {
  let body = '';
  if (payload.body && payload.body.data) { // Simplest case: non-multipart, direct body data
    body = Buffer.from(payload.body.data, 'base64').toString('utf-8');
  } else if (payload.parts) {
    const stack = [...payload.parts];
    while(stack.length > 0) {
      const part = stack.pop();
      if (part.mimeType === 'text/plain' && part.body && part.body.data) {
        body = Buffer.from(part.body.data, 'base64').toString('utf-8');
        break; // Prefer plain text
      } else if (part.mimeType === 'text/html' && part.body && part.body.data && !body) { // If no plain text found yet
        const htmlBody = Buffer.from(part.body.data, 'base64').toString('utf-8');
        // Basic HTML to text conversion
        body = htmlBody
          .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')       // Remove style tags
          .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')      // Remove script tags
          .replace(/<br\s*\/?>/gi, '\n')                         // Convert <br> to newline
          .replace(/<\/p>/gi, '\n\n')                            // Convert </p> to double newline
          .replace(/<\/div>/gi, '\n')                            // Convert </div> to newline
          .replace(/<[^>]+>/g, '')                               // Remove all other HTML tags
          .replace(/&nbsp;/g, ' ')                              // Non-breaking space
          .replace(/&amp;/g, '&')                               // Ampersand
          .replace(/&lt;/g, '<')                                // Less than
          .replace(/&gt;/g, '>')                                // Greater than
          .replace(/&quot;/g, '"')                              // Double quote
          .replace(/&apos;/g, "'")                              // Single quote (or &#39;)
          .replace(/&#39;/g, "'");                              // Single quote HTML entity
      } else if (part.parts) { // Handle nested multipart
        stack.push(...part.parts.reverse()); // Add nested parts to stack, reverse to process in order
      }
    }
  }
  // Clean up common issues like excessive newlines, leading/trailing whitespace per line
  return body.replace(/\r\n/g, '\n').replace(/\n{3,}/g, '\n\n').replace(/^\s+|\s+$/gm, '').trim().substring(0, 10000); // Increased char limit slightly
}

async function getCalendarEvents(auth) {
  const calendar = google.calendar({ version: 'v3', auth });
  const now = new Date();
  const sixtyDaysAgo = new Date(now.getTime() - (60 * 24 * 60 * 60 * 1000));
  
  const calendarIdToFetch = process.env.GOOGLE_CALENDAR_ID;
  if (!calendarIdToFetch) {
      logMessage("GOOGLE_CALENDAR_ID environment variable is not set. Please set it to the target calendar ID. Defaulting to 'primary', but this may not be correct.");
  }

  const response = await calendar.events.list({
    calendarId: calendarIdToFetch || 'primary',
    timeMin: sixtyDaysAgo.toISOString(),
    timeMax: now.toISOString(),
    singleEvents: true,
    orderBy: 'startTime',
    maxResults: 250
  });

  const keywords = ['investor', 'pitch', 'intro', 'funding', 'vc', 'investment', 'demo', 'meeting', 'vie', 'capital', 'ventures', 'fund', 'consultation', 'session', 'call', 'sync', 'discussion', 'strategy', 'update'];
  const vcPatterns = [/ventures?/i, /capital/i, /\bfund\b/i, /partners?/i, /investments?/i, /\.vc/i, /@.*ventures/i, /@.*capital/i, /@.*fund/i, /angel\sgroup/i];
  const allEvents = response.data.items || [];
  
  logMessage(`[DEBUG] Total events fetched before filtering: ${allEvents.length} from calendar "${calendarIdToFetch || 'primary'}"`);

  const filteredEvents = allEvents.filter(event => {
    const title = (event.summary || '').toLowerCase();
    const description = (event.description || '').toLowerCase();
    const attendeeEmails = event.attendees?.map(a => a.email?.toLowerCase()).filter(Boolean) || [];
    const organizerEmail = event.organizer?.email?.toLowerCase() || '';

    // Skip if no external attendees (assuming internal domain is 'viehq.com')
    const hasExternalAttendees = attendeeEmails.some(e => !shouldSkipEmail(e) && !e.includes(process.env.INTERNAL_DOMAIN || 'viehq.com'));
    if (!hasExternalAttendees && !attendeeEmails.some(e => vcPatterns.some(p => p.test(e)))) {
        // logMessage(`[DEBUG] Event "${event.summary||'No Summary'}" FILTERED OUT (No external attendees relevant)`);
        return false;
    }
    
    const hasKeywords = keywords.some(k => title.includes(k) || description.includes(k));
    const hasVCPatternsInMeta = vcPatterns.some(p => p.test(title) || p.test(description) || vcPatterns.some(vp => attendeeEmails.some(e => vp.test(e))) || vcPatterns.some(vp => vp.test(organizerEmail)));
    
    const matchesFilter = hasKeywords || hasVCPatternsInMeta;
    // logMessage(`[DEBUG] Event "${event.summary||'No Summary'}": ${matchesFilter?'INCLUDED':'FILTERED OUT'} (K:${hasKeywords}, VCP:${hasVCPatternsInMeta}, ExtA:${hasExternalAttendees})`);
    return matchesFilter;
  });
  logMessage(`[DEBUG] Events after filtering: ${filteredEvents.length}`);
  return filteredEvents;
}

async function getSheetContacts(auth) {
  const sheets = google.sheets({ version: 'v4', auth });
  try {
    const response = await sheets.spreadsheets.values.get({
      spreadsheetId: process.env.GOOGLE_SHEET_ID,
      range: 'Contacts!A:G' // Name, Email, Status, Next Step, Notes, Last Meeting, Created At
    });
    const rows = response.data.values || [];
    if (rows.length <= 1) return []; // No data or only header
    // Assumes header row is present
    const header = rows[0].map(h => h.trim());
    const emailIndex = header.indexOf('Email');
    if (emailIndex === -1) throw new Error("Sheet 'Contacts' must have an 'Email' column.");

    return rows.slice(1).map(row => ({
      name: row[header.indexOf('Name')] || '',
      email: row[emailIndex] || '',
      status: row[header.indexOf('Status')] || '',
      nextStep: row[header.indexOf('Next Step')] || '',
      notes: row[header.indexOf('Notes')] || '',
      lastMeeting: row[header.indexOf('Last Meeting')] || '',
      createdAt: row[header.indexOf('Created At')] || ''
    })).filter(c => c.email && !shouldSkipEmail(c.email)); // Filter out rows without email or skipped emails
  } catch (e) {
    logMessage(`Error reading contacts from sheet: ${e.message}`);
    return []; // Return empty on error to avoid breaking sync
  }
}

async function updateSheetContacts(auth, contactsToUpdate, existingContacts) {
    const sheets = google.sheets({ version: 'v4', auth });
    const sheetName = 'Contacts';
    const header = ['Name', 'Email', 'Status', 'Next Step', 'Notes', 'Last Meeting', 'Created At'];
    
    // Create a map of existing contacts by email for quick lookup
    const existingContactsMap = new Map();
    existingContacts.forEach(contact => {
        if (contact.email) existingContactsMap.set(contact.email, contact);
    });

    const allContactsMap = new Map(existingContactsMap);

    // Merge new/updated contacts
    contactsToUpdate.forEach(contact => {
        if (contact.email && !shouldSkipEmail(contact.email)) {
            const existing = allContactsMap.get(contact.email);
            if (existing) { // Merge if exists
                allContactsMap.set(contact.email, { ...existing, ...contact });
            } else { // Add if new
                allContactsMap.set(contact.email, {
                    createdAt: new Date().toISOString(), // Ensure new contacts have a creation date
                    ...contact
                });
            }
        }
    });

    const finalContactsList = Array.from(allContactsMap.values())
      .sort((a,b) => (a.name || "").localeCompare(b.name || "")); // Sort by name for consistency

    const values = [header];
    finalContactsList.forEach(c => {
        values.push([
            c.name || getNameFromEmail(c.email),
            c.email || '',
            c.status || 'N/A',
            c.nextStep || 'N/A',
            c.notes || '',
            c.lastMeeting || '',
            c.createdAt || new Date().toISOString() // Fallback createdAt for any older items missing it
        ]);
    });

    try {
        // Clear existing data (except header) before writing, to handle deletions or full overwrites
        // Be cautious with clear if sheet has other important data/formulas outside A:G
        await sheets.spreadsheets.values.clear({
            spreadsheetId: process.env.GOOGLE_SHEET_ID,
            range: `${sheetName}!A2:G` // Clear data rows, keeping header in row 1
        });
        logMessage(`Cleared existing contacts in sheet (A2:G). Preparing to write ${finalContactsList.length} contacts.`);

        await sheets.spreadsheets.values.update({
            spreadsheetId: process.env.GOOGLE_SHEET_ID,
            range: `${sheetName}!A1:G${values.length}`, // Write header + all data
            valueInputOption: 'USER_ENTERED', // Or 'RAW' if no formulas/dates needing parsing
            resource: { values }
        });
        logMessage(`Successfully wrote ${finalContactsList.length} contacts to sheet.`);
    } catch (e) {
        logMessage(`Error updating sheet: ${e.message}`);
        console.error("Sheet update error details:", e);
        throw e; // Re-throw to fail sync if sheet update fails
    }
}


async function getFirefliesTranscript(email, meetingDate) {
  if (!process.env.FIREFLIES_API_KEY) throw new Error('Fireflies API key not configured.');
  
  // Fireflies API expects date, not datetime, for fromDate/toDate in listing
  // We'll search for transcripts on the day of the meeting
  const searchDate = new Date(meetingDate);
  const startDate = new Date(searchDate.setHours(0, 0, 0, 0)).toISOString(); // Start of meeting day
  const endDate = new Date(searchDate.setHours(23, 59, 59, 999)).toISOString(); // End of meeting day

  try {
    // Step 1: List transcripts around the meeting date that include the participant
    const listResponse = await axios.post('https://api.fireflies.ai/graphql', {
      query: `
        query GetTranscripts($fromDate: DateTime!, $toDate: DateTime!, $participantEmails: [String!]) {
          transcripts(fromDate: $fromDate, toDate: $toDate, limit: 10, participantEmails: $participantEmails) {
            id
            title
            date
            participants { email name }
          }
        }
      `,
      variables: { fromDate: startDate, toDate: endDate, participantEmails: [email] }
    }, { headers: { 'Authorization': `Bearer ${process.env.FIREFLIES_API_KEY}`, 'Content-Type': 'application/json' } });

    const transcripts = listResponse.data?.data?.transcripts || [];
    if (transcripts.length === 0) {
      logMessage(`No Fireflies transcripts found for ${email} between ${startDate} and ${endDate}.`);
      return null;
    }
    
    // Find the best match - Fireflies API can be tricky with exact timing.
    // We assume the first one involving the email on that day is the most relevant if multiple.
    const matchedTranscript = transcripts.find(t => t.participants?.some(p => p.email === email));

    if (!matchedTranscript) {
      logMessage(`No transcript specifically matching ${email} as participant on meeting day, though some were found in range.`);
      return null;
    }
    logMessage(`Found potential Fireflies transcript "${matchedTranscript.title}" (ID: ${matchedTranscript.id}) for ${email}. Fetching details.`);

    // Step 2: Fetch the full transcript content for the matched ID
    const transcriptDetailResponse = await axios.post('https://api.fireflies.ai/graphql', {
      query: `
        query GetSpecificTranscript($transcriptId: String!) {
          transcript(id: $transcriptId) {
            id
            title
            date
            sentences {
              text
              speaker_name
            }
            participants { email name }
          }
        }
      `,
      variables: { transcriptId: matchedTranscript.id }
    }, { headers: { 'Authorization': `Bearer ${process.env.FIREFLIES_API_KEY}`, 'Content-Type': 'application/json' } });

    const fullTranscriptData = transcriptDetailResponse.data?.data?.transcript;
    if (!fullTranscriptData || !fullTranscriptData.sentences || fullTranscriptData.sentences.length === 0) {
      logMessage(`Fireflies transcript ID ${matchedTranscript.id} has no sentences.`);
      return null;
    }

    const transcriptText = fullTranscriptData.sentences.map(s => `${s.speaker_name || 'Speaker'}: ${s.text}`).join('\n');
    logMessage(`Retrieved Fireflies transcript for ${email} - Title: "${fullTranscriptData.title}", ${transcriptText.length} chars.`);
    return transcriptText;

  } catch (e) {
    const errorMessage = e.response?.data?.errors?.[0]?.message || e.message;
    logMessage(`Fireflies API error for ${email}: ${errorMessage}`);
    // Don't throw here, allow fallback to other note sources
    return null; 
  }
}

