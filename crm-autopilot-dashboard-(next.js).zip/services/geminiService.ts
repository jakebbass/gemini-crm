
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_SUMMARIZATION_PROMPT_TEMPLATE, GEMINI_MODEL_NAME } from '../constants';
import { GeminiSummaryResponse } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("Gemini API key (process.env.API_KEY) is not set. Summarization will not work.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "MISSING_API_KEY" }); // Fallback to prevent crash if key is missing, but functionality will be broken.

export const summarizeTranscriptWithGemini = async (
  transcript: string
): Promise<GeminiSummaryResponse> => {
  if (!API_KEY) {
    throw new Error("Gemini API key is not configured. Please set the API_KEY environment variable.");
  }

  const prompt = GEMINI_SUMMARIZATION_PROMPT_TEMPLATE(transcript);

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.2, // Lower temperature for more deterministic factual extraction
        topK: 32,
        topP: 0.9,
      }
    });
    
    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s; // Matches ```json ... ``` or ``` ... ```
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }

    try {
      const parsedData = JSON.parse(jsonStr) as GeminiSummaryResponse;
      // Ensure all expected fields are present, even if empty, for consistency
      return {
        contactName: parsedData.contactName || "N/A",
        status: parsedData.status || "N/A",
        nextStep: parsedData.nextStep || "N/A",
        urgentInfo: parsedData.urgentInfo || "N/A",
        fullSummary: parsedData.fullSummary || "Could not generate summary.",
      };
    } catch (parseError) {
      console.error("Failed to parse Gemini JSON response:", parseError);
      console.error("Raw Gemini response text:", response.text);
      // Fallback if JSON parsing fails but we have text
      return {
        fullSummary: `Error parsing summary. Raw response: ${response.text.substring(0, 500)}${response.text.length > 500 ? '...' : ''}`,
        contactName: "Error",
        status: "Error",
        nextStep: "Error",
        urgentInfo: "Error",
      };
    }

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    let errorMessage = "An unknown error occurred while summarizing.";
    if (error instanceof Error) {
      errorMessage = error.message;
    }
    // Provide a structured error response
    return {
      fullSummary: `Failed to generate summary: ${errorMessage}`,
      contactName: "Error",
      status: "Error",
      nextStep: "Error",
      urgentInfo: "Error",
    };
  }
};
