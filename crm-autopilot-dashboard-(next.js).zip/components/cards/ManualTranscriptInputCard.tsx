
import React, { useState } from 'react';
import { Button } from '../ui/Button';
import { TextArea } from '../ui/TextArea';

interface ManualTranscriptInputCardProps {
  className?: string;
  onTranscriptSubmit: (transcript: string) => void;
}

export const ManualTranscriptInputCard: React.FC<ManualTranscriptInputCardProps> = ({ 
  className = '', 
  onTranscriptSubmit 
}) => {
  const [localTranscript, setLocalTranscript] = useState<string>('');

  const handleUseTranscript = () => {
    onTranscriptSubmit(localTranscript);
  };

  return (
    <div className={`bg-white p-4 sm:p-6 rounded-xl shadow-lg ${className}`}>
      <h2 className="text-xl font-semibold text-slate-800 mb-4">Manual Transcript Input</h2>
      <p className="text-sm text-slate-600 mb-3">
        Paste any meeting transcript here. You can then use the "Meeting Transcript Summarizer" card 
        to process it with Gemini. This is useful for testing with transcripts from various sources,
        like Fireflies.ai or email content.
      </p>
      
      <TextArea
        label="Paste Full Transcript Here:"
        value={localTranscript}
        onChange={(e) => setLocalTranscript(e.target.value)}
        rows={8}
        placeholder="Enter the full meeting transcript..."
        className="mb-4 text-sm"
      />

      <Button 
        onClick={handleUseTranscript} 
        disabled={!localTranscript.trim()}
        className="w-full sm:w-auto"
        variant="secondary"
      >
        Use this transcript for Summarizer
      </Button>
    </div>
  );
};
