
import React from 'react';

interface MetricCardProps {
  label: string;
  value: string | number;
  icon?: React.ReactNode;
  className?: string;
}

export const MetricCard: React.FC<MetricCardProps> = ({ label, value, icon, className = '' }) => {
  return (
    <div className={`bg-white p-4 sm:p-6 rounded-xl shadow-lg flex items-center space-x-4 ${className}`}>
      {icon && (
        <div className="flex-shrink-0 p-3 bg-blue-100 rounded-full">
          {icon}
        </div>
      )}
      <div>
        <p className="text-sm font-medium text-slate-500 truncate">{label}</p>
        <p className="mt-1 text-2xl sm:text-3xl font-semibold text-slate-900">{value}</p>
      </div>
    </div>
  );
};
