
import React from 'react';
import { Task } from '../../types';

interface TaskListCardProps {
  tasks: Task[];
  className?: string;
}

const priorityStyles: Record<Task['priority'], string> = {
  High: 'bg-red-100 text-red-700 border-red-200',
  Medium: 'bg-yellow-100 text-yellow-700 border-yellow-200',
  Low: 'bg-green-100 text-green-700 border-green-200',
};

export const TaskListCard: React.FC<TaskListCardProps> = ({ tasks, className = '' }) => {
  return (
    <div className={`bg-white p-4 sm:p-6 rounded-xl shadow-lg ${className}`}>
      <h2 className="text-xl font-semibold text-slate-800 mb-4">Pending Tasks</h2>
      {tasks.filter(task => !task.isCompleted).length === 0 ? (
         <p className="text-slate-500 text-sm">No pending tasks. Great job!</p>
      ) : (
        <ul className="space-y-3 max-h-96 overflow-y-auto pr-2">
          {tasks.filter(task => !task.isCompleted).map((task) => (
            <li key={task.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition-colors">
              <div className="flex items-center space-x-3">
                 <input type="checkbox" checked={task.isCompleted} readOnly className="form-checkbox h-4 w-4 text-blue-600 border-slate-300 rounded focus:ring-blue-500 cursor-not-allowed" />
                <div>
                  <p className={`text-sm font-medium ${task.isCompleted ? 'line-through text-slate-500' : 'text-slate-800'}`}>
                    {task.description}
                  </p>
                  <p className="text-xs text-slate-500">Due: {task.dueDate}</p>
                </div>
              </div>
              <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${priorityStyles[task.priority]}`}>
                {task.priority}
              </span>
            </li>
          ))}
        </ul>
      )}
      {tasks.filter(task => task.isCompleted).length > 0 && (
        <>
          <h3 className="text-md font-semibold text-slate-700 mt-6 mb-3 pt-3 border-t border-slate-200">Completed Tasks</h3>
           <ul className="space-y-3 max-h-48 overflow-y-auto pr-2">
            {tasks.filter(task => task.isCompleted).map((task) => (
              <li key={task.id} className="flex items-center justify-between p-3 bg-green-50 rounded-lg opacity-70">
                <div className="flex items-center space-x-3">
                  <input type="checkbox" checked={task.isCompleted} readOnly className="form-checkbox h-4 w-4 text-green-600 border-slate-300 rounded focus:ring-green-500 cursor-not-allowed" />
                  <div>
                    <p className="text-sm font-medium line-through text-slate-500">
                      {task.description}
                    </p>
                    <p className="text-xs text-slate-400">Due: {task.dueDate}</p>
                  </div>
                </div>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded-full border ${priorityStyles[task.priority]} opacity-80`}>
                  {task.priority}
                </span>
              </li>
            ))}
          </ul>
        </>
      )}
    </div>
  );
};
