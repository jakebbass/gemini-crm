
import React from 'react';

interface HeaderProps {
  title: string;
}

export const Header: React.FC<HeaderProps> = ({ title }) => {
  return (
    <header className="bg-slate-800 text-white shadow-md">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center">
        <h1 className="text-xl sm:text-2xl font-semibold tracking-tight">{title}</h1>
        {/* Placeholder for user avatar or actions */}
        <div className="ml-auto">
           {/* <img src="https://picsum.photos/40/40" alt="User Avatar" className="w-8 h-8 rounded-full" /> */}
        </div>
      </div>
    </header>
  );
};
