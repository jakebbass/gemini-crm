
import React, { useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/Button';
import { TextArea } from '@/components/ui/TextArea';
import { LoadingSpinner } from '@/components/ui/LoadingSpinner';
import { summarizeTranscriptWithGemini } from '@/services/geminiService';
import { GeminiSummaryResponse } from '@/types';

interface TranscriptSummarizerCardProps {
  className?: string;
  transcript: string;
  onTranscriptChange: (transcript: string) => void;
}

export const TranscriptSummarizerCard: React.FC<TranscriptSummarizerCardProps> = ({ 
  className = '', 
  transcript, 
  onTranscriptChange 
}) => {
  const [summary, setSummary] = useState<GeminiSummaryResponse | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = useCallback(async () => {
    if (!transcript.trim()) {
      setError('Please enter or provide a transcript to summarize.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setSummary(null);
    try {
      const result = await summarizeTranscriptWithGemini(transcript);
      setSummary(result);
      if(result.fullSummary.startsWith("Failed to generate summary:") || result.fullSummary.startsWith("Error parsing summary.")){
        setError(result.fullSummary);
      }
    } catch (e: any) {
      setError(e.message || 'An unexpected error occurred.');
      console.error("Summarization error:", e);
    } finally {
      setIsLoading(false);
    }
  }, [transcript]);

  useEffect(() => {
    if (!transcript.trim()) {
      setSummary(null);
      setError(null);
    }
  }, [transcript]);

  return (
    <div className={`bg-white p-4 sm:p-6 rounded-xl shadow-lg ${className}`}>
      <h2 className="text-xl font-semibold text-slate-800 mb-4">Meeting Transcript Summarizer</h2>
      
      <TextArea
        label="Meeting Transcript to Summarize:"
        value={transcript}
        onChange={(e) => onTranscriptChange(e.target.value)}
        rows={8}
        placeholder="Paste transcript here or provide it via 'Manual Transcript Input' card..."
        className="mb-4 text-sm"
        disabled={isLoading}
      />

      <Button onClick={handleSubmit} isLoading={isLoading} disabled={isLoading || !transcript.trim()} className="w-full sm:w-auto">
        Summarize with Gemini
      </Button>

      {isLoading && <LoadingSpinner message="Generating summary..." className="mt-6" />}

      {error && !isLoading && (
        <div className="mt-6 p-3 bg-red-50 border border-red-200 rounded-md text-red-700 text-sm" role="alert">
          <h4 className="font-semibold mb-1">Error</h4>
          <p>{error}</p>
        </div>
      )}

      {summary && !isLoading && !error && (
        <div className="mt-6 space-y-4">
          <h3 className="text-lg font-semibold text-slate-700">Summary Results:</h3>
          {(summary.contactName && summary.contactName !== "N/A" && summary.contactName !== "Error") && (
            <div>
              <h4 className="text-sm font-medium text-slate-500">Contact Name(s)</h4>
              <p className="text-slate-800 text-sm bg-slate-50 p-2 rounded-md">{summary.contactName}</p>
            </div>
          )}
          {(summary.status && summary.status !== "N/A" && summary.status !== "Error") && (
            <div>
              <h4 className="text-sm font-medium text-slate-500">Status / Sentiment</h4>
              <p className="text-slate-800 text-sm bg-slate-50 p-2 rounded-md">{summary.status}</p>
            </div>
          )}
          {(summary.nextStep && summary.nextStep !== "N/A" && summary.nextStep !== "Error") && (
            <div>
              <h4 className="text-sm font-medium text-slate-500">Next Steps</h4>
              <p className="text-slate-800 text-sm bg-slate-50 p-2 rounded-md whitespace-pre-wrap">{summary.nextStep}</p>
            </div>
          )}
           {(summary.urgentInfo && summary.urgentInfo !== "N/A" && summary.urgentInfo !== "Error") && (
            <div>
              <h4 className="text-sm font-medium text-slate-500">Urgent Info</h4>
              <p className="text-slate-800 text-sm bg-red-50 p-2 rounded-md border border-red-100 whitespace-pre-wrap">{summary.urgentInfo}</p>
            </div>
          )}
          <div>
            <h4 className="text-sm font-medium text-slate-500">Full Summary</h4>
            <p className="text-slate-800 text-sm bg-slate-50 p-3 rounded-md whitespace-pre-wrap">{summary.fullSummary}</p>
          </div>
        </div>
      )}
       {!summary && !isLoading && !error && transcript && (
        <div className="mt-6 p-3 bg-blue-50 border border-blue-200 rounded-md text-blue-700 text-sm">
            <p>Transcript ready. Click "Summarize with Gemini" to see results.</p>
        </div>
       )}
        {!transcript && !isLoading && !error && (
         <div className="mt-6 p-3 bg-slate-50 border border-slate-200 rounded-md text-slate-600 text-sm">
            <p>Enter a transcript above or use the 'Manual Transcript Input' card.</p>
        </div>
        )}
    </div>
  );
};
