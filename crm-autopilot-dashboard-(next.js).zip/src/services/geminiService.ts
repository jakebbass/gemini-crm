
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { GEMINI_SUMMARIZATION_PROMPT_TEMPLATE, GEMINI_MODEL_NAME } from '@/constants';
import { GeminiSummaryResponse } from "@/types";

// For client-side Next.js, environment variables must be prefixed with NEXT_PUBLIC_
// Ensure this is set in your .env.local file (e.g., NEXT_PUBLIC_GEMINI_API_KEY=your_api_key)
const API_KEY = process.env.NEXT_PUBLIC_GEMINI_API_KEY;

let ai: GoogleGenAI | null = null;

if (!API_KEY) {
  console.error("Gemini API key (NEXT_PUBLIC_GEMINI_API_KEY) is not set. Client-side summarization will not work.");
} else {
  ai = new GoogleGenAI({ apiKey: API_KEY });
}

export const summarizeTranscriptWithGemini = async (
  transcript: string
): Promise<GeminiSummaryResponse> => {
  if (!ai) { // Check if ai was initialized
    throw new Error("Gemini API client is not initialized. Please set the NEXT_PUBLIC_GEMINI_API_KEY environment variable.");
  }

  const prompt = GEMINI_SUMMARIZATION_PROMPT_TEMPLATE(transcript);

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_MODEL_NAME,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.2,
        topK: 32,
        topP: 0.9,
      }
    });
    
    let jsonStr = response.text.trim();
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
      jsonStr = match[2].trim();
    }

    try {
      const parsedData = JSON.parse(jsonStr) as GeminiSummaryResponse;
      return {
        contactName: parsedData.contactName || "N/A",
        status: parsedData.status || "N/A",
        nextStep: parsedData.nextStep || "N/A",
        urgentInfo: parsedData.urgentInfo || "N/A",
        fullSummary: parsedData.fullSummary || "Could not generate summary.",
      };
    } catch (parseError) {
      console.error("Failed to parse Gemini JSON response:", parseError);
      console.error("Raw Gemini response text:", response.text);
      return {
        fullSummary: `Error parsing summary. Raw response: ${response.text.substring(0, 500)}${response.text.length > 500 ? '...' : ''}`,
        contactName: "Error",
        status: "Error",
        nextStep: "Error",
        urgentInfo: "Error",
      };
    }

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    let errorMessage = "An unknown error occurred while summarizing.";
    if (error instanceof Error) {
      errorMessage = error.message;
    }
    return {
      fullSummary: `Failed to generate summary: ${errorMessage}`,
      contactName: "Error",
      status: "Error",
      nextStep: "Error",
      urgentInfo: "Error",
    };
  }
};
